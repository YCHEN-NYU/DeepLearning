# Neural Network with Backpropagation

A simple Python script showing how the backpropagation algorithm works.

Checkout this blog post for background: [A Step by Step Backpropagation Example](http://mattmazur.com/2015/03/17/a-step-by-step-backpropagation-example/).

# Contact

If you have any suggestions, find a bug, or just want to say hey drop me a note at [@mhmazur](https://twitter.com/mhmazur) on Twitter or by email at matthew.h.mazur@gmail.com.

# License

MIT © [Matt Mazur](http://mattmazur.com)
